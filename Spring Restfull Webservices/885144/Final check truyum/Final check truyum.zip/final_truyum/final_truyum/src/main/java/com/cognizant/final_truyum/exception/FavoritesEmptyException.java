package com.cognizant.final_truyum.exception;

public class FavoritesEmptyException extends Exception {
	public FavoritesEmptyException(String message)
	{
		super(message);
	}

}
